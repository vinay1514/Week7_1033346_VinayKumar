package org.infinite.VizagMunicipalCorporation.repository;

import java.util.List;

import org.infinite.VizagMunicipalCorporation.model.Complaint;

public interface IComplaintDao {
	List<Complaint> getAllComplaints();

	public Complaint addComplaint(Complaint comp);

}
