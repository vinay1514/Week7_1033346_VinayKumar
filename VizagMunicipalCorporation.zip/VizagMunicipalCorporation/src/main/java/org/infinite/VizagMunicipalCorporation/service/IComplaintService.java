package org.infinite.VizagMunicipalCorporation.service;

import java.util.List;

import org.infinite.VizagMunicipalCorporation.model.Complaint;

public interface IComplaintService {
	public List<Complaint> getAllComplaints();

	public Complaint addComplaint(Complaint com);

}
