package org.infinite.VizagMunicipalCorporation.controller;

import org.infinite.VizagMunicipalCorporation.model.Complaint;
import org.infinite.VizagMunicipalCorporation.service.ComplaintServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ComplaintController {
	@Autowired
	ComplaintServiceImpl csimpl;
//controller for COmplaint
	@RequestMapping(value = "/getAllComplaints/{username}", method = RequestMethod.GET)
	public String getAllComplaints(Model m) {
		//using Model
		m.addAttribute("Complaint", new Complaint());
		m.addAttribute("listOfComplaints", csimpl.getAllComplaints());
		return "complaint";
	}

	@RequestMapping(value = "/addComplaint", method = RequestMethod.POST)
	public String addComplaint(@ModelAttribute("Complaint") Complaint com) {
		csimpl.addComplaint(com);
		return "redirect:/getAllComplaints";
	}
}
