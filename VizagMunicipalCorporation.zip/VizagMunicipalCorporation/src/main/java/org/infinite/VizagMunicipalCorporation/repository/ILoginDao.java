package org.infinite.VizagMunicipalCorporation.repository;

import org.infinite.VizagMunicipalCorporation.model.Login;

public interface ILoginDao {
	void save(Login username);

	Login findByName(String userName);
}
