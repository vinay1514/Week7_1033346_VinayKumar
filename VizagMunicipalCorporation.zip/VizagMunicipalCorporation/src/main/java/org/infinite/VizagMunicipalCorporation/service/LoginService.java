package org.infinite.VizagMunicipalCorporation.service;

import org.infinite.VizagMunicipalCorporation.repository.LoginDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public  class LoginService implements ILogin {
	@Autowired
	LoginDaoImpl lmpl;
	public void save(String userName) {
		// TODO Auto-generated method stub
		lmpl.save(userName);
		
	}
	public void findByName(String userName) {
		// TODO Auto-generated method stub
		lmpl.findByName(userName);
	}

	
}
