package org.infinite.VizagMunicipalCorporation.controller;

import org.infinite.VizagMunicipalCorporation.service.LoginService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

	@RequestMapping("/login")
	public String login(@RequestParam String username, @RequestParam String password, Model model,
			RedirectAttributes redirectAttributes) {
		Login user =LoginService();

		if (user != null && user.getPassword().equals(password)) {
			model.addAttribute("user", user);

			return "redirect:/complaint";
		} else {
			redirectAttributes.addFlashAttribute("loginError", "Invalid username or password");
			return "redirect:/login";
		}
	}
}
