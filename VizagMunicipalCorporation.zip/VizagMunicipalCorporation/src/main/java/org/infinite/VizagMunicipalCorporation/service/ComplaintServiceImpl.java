package org.infinite.VizagMunicipalCorporation.service;

import java.util.List;

import javax.transaction.Transactional;

import org.infinite.VizagMunicipalCorporation.model.Complaint;
import org.infinite.VizagMunicipalCorporation.repository.ComplaintDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ComplaintServiceImpl implements IComplaintService{
	@Autowired
	ComplaintDaoImpl cmpl;
	@Transactional
	public List<Complaint> getAllComplaints() {
		// TODO Auto-generated method stub
		return cmpl.getAllComplaints();
	}

	@Transactional
	public Complaint addComplaint(Complaint com) {
		return cmpl.addComplaint(com);
	}

}
