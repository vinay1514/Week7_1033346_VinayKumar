package org.infinite.VizagMunicipalCorporation.service;

public interface ILogin {
	void save(String username);

	public void findByName(String userName);
}
